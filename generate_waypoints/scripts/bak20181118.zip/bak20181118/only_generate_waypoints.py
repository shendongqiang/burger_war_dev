#!/usr/bin/env python

import os
import rospy

from move_base_msgs.msg import MoveBaseActionGoal


path_w = '/home/ubuntu/catkin_ws/src/generte_waypoints/scripts/patrol_waypoints.txt'

def callback(data):
    pos = data.goal.target_pose.pose
    with open(path_w) as f:
       #count rows
       num=len(f.readlines()) 

    print "[{0},({1},{2},0.0),(0.0,0.0,{3},{4})],".format(num-1,pos.position.x,pos.position.y,pos.orientation.z,pos.orientation.w)

    with open(path_w, mode='a') as f:
       #f.writelines(pos.position.x,",",pos.position.y,",",pos.orientation.z,",",pos.orientation.w,os.linesep)
       #f.write(pos.position.x,",",pos.position.y,",",pos.orientation.z,",",pos.orientation.w,os.linesep)
       #f.write("[({0},{1},0.0),(0.0,0.0,{2},{3})],".format(pos.position.x,pos.position.y,pos.orientation.z,pos.orientation.w))
       #f.write("{0},{1},0.0,0.0,0.0,{2},{3}".format(pos.position.x,pos.position.y,pos.orientation.z,pos.orientation.w))
       f.write("{0},{1},{2},0.0,0.0,0.0,{3},{4}".format(num-1,pos.position.x,pos.position.y,pos.orientation.z,pos.orientation.w))
       f.write(os.linesep)

def listener():

    rospy.init_node('generate_waypoints', anonymous=True)

    rospy.Subscriber("/move_base/goal", MoveBaseActionGoal, callback)

    rospy.spin()

if __name__ == '__main__':
    listener()
